def acchafunc(number):
    print("This is inside accha func")
    return number
