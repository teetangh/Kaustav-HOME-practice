class Accha:
    """ This is the Accha class """
    def __init__(self):
        print("Constructor ban gaya")

    def acchafunc(self,number):
        print("This is inside accha func")
        return number
