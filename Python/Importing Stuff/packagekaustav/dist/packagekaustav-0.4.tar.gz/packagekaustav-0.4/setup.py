from setuptools import setup
# from setuptools import find_packages

setup(
    name="packagekaustav",
    version="0.4",
    description="This is code with kaustav package",
    long_description="This is a very very long description",
    packages=["packagekaustav"],
    install_requires=[])
