class Accha:

    def __init__(self):
        print("Constructor ban gaya")

    def acchafunc(self,number):
        print("This is inside accha func")
        return number
